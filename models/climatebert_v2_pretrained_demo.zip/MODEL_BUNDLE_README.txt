ClimateBERT v2 — pretrained demo model bundle
================================================

Place these files in your repo clone:

  outputs/climatebert_v2/embedding_lr_multiclass.joblib
  outputs/climatebert_v2/embedding_lr_binary_nihilism.joblib
  outputs/climatebert_v2/climatebert_metrics.json

Then test:

  pip install -r requirements.txt
  export PYTHONPATH=src
  python -m demo.inference --text "Your sentence here" --version v2
  streamlit run app/streamlit_app.py

Training details:
  - Encoder: climatebert/distilroberta-base-climate-f (downloaded from Hugging Face on first run)
  - Classifier: logistic regression on embeddings
  - Dataset: v2, ~16,713 labeled comments, 70/15/15 split

To retrain from scratch (needs data/processed/cleaned_data-2.csv):

  python src/climatebert/prepare_v2_dataset.py
  python src/climatebert/train.py --dataset-version v2
